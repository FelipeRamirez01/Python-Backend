from boa_constrictor import Boa_Constrictor
from huron import Huron


boa1 = Boa_Constrictor("Maxi", 13000, 44, "Colombia", 200.2)
boa1.agregar_raton(2)

print(boa1.ratones_comidos())
print(boa1.hacer_sonido())
boa1.agregar_raton(2)
print(boa1.ratones_comidos())

huron1 = Huron("Max", 200, 4, "Mexico", 50.1)

print(huron1.hacer_sonido())

print(huron1.obtener_nombre())

print(boa1.calcular_flete())



