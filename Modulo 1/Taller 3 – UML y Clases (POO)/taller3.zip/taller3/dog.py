from pet_food import PetFood

class Dog:
    """
    Esta clase representa a un perro.

    Atributos:
        name (str): Nombre del perro.
        breed (str): Raza del perro.
        weight (float): Peso del perro en decimales.
        age (int): Edad del perro.
    """

    # Constructor
    def __init__(self, name:str, breed:str, weight:float, age:int, pet_food:PetFood) -> None:
        """
        Inicializa la clase con los valores de todos los atributos de la clase.

        Se valida que cada valor enviado por parametro corresponda al tipo de dato del atributo
        """
        self.name = name
        self.breed = breed
        self.weight = weight
        self.age = age
        self.pet_food = pet_food

    # Metodos
    def get_data(self):
        return f'{self.name} ({self.breed}): {self.weight}|{self.age} - {self.pet_food.name}'

    # Getters y Setters
    @property
    def name(self) -> str:
        """ Devuelve el valor del atributo privado 'name' """
        return self.__name
    
    @name.setter
    def name(self, value:str) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'name'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, str):
            self.__name = value
        else:
            raise ValueError('Expected str')
        
    @property
    def breed(self) -> str:
        """ Devuelve el valor del atributo privado 'breed' """
        return self.__breed
    
    @breed.setter
    def breed(self, value:str) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'breed'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, str):
            self.__breed = value
        else:
            raise ValueError('Expected str')
        
    @property
    def weight(self) -> float:
        """ Devuelve el valor del atributo privado 'weight' """
        return self.__weight
    
    @weight.setter
    def weight(self, value:float) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'weight'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, float):
            self.__weight = value
        else:
            raise ValueError('Expected float')
        
    @property
    def age(self) -> int:
        """ Devuelve el valor del atributo privado 'age' """
        return self.__age
    
    @age.setter
    def age(self, value:int) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'age'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, int):
            self.__age = value
        else:
            raise ValueError('Expected int')
        
    @property
    def pet_food(self) -> PetFood:
        """ Devuelve el valor del atributo privado 'pet_food' """
        return self.__pet_food
    
    @pet_food.setter
    def pet_food(self, value:PetFood) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'pet_food'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, PetFood):
            self.__pet_food = value
        else:
            raise ValueError('Expected PetFood')