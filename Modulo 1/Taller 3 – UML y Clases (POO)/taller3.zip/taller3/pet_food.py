class PetFood:
    """
    Esta clase representa a un concentrado para animales.

    Atributos:
        name (str): Nombre del concentrado.
        price (int): Precio del concentrado.
        calories (float): Calorias del concentrado.
        invima (str): código de registro del Instituto Nacional de Vigilancia de Medicamentos y Alimentos (INVIMA).
    """

    # Constructor
    def __init__(self, name:str, price:int, calories:float, invima:str) -> None:
        """
        Inicializa la clase con los valores de todos los atributos de la clase.

        Se valida que cada valor enviado por parametro corresponda al tipo de dato del atributo
        """
        self.name = name
        self.price = price
        self.calories = calories
        self.__invima = invima

    # Metodos
    def get_data(self) -> str:
        return f'{self.name} (${self.price})' 
    
    def calculate_profitability(self) -> float:
        return round(self.price / self.calories, 2)

    # Getters y Setters
    @property
    def name(self) -> str:
        """ Devuelve el valor del atributo privado 'name' """
        return self.__name
    
    @name.setter
    def name(self, value:str) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'name'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, str):
            self.__name = value
        else:
            raise ValueError('Expected str')
        
    @property
    def price(self) -> int:
        """ Devuelve el valor del atributo privado 'price' """
        return self.__price
    
    @price.setter
    def price(self, value:int) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'price'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, int):
            self.__price = value
        else:
            raise ValueError('Expected int')
        
    @property
    def calories(self) -> float:
        """ Devuelve el valor del atributo privado 'calories' """
        return self.__calories
    
    @calories.setter
    def calories(self, value:float) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'calories'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, float) and value > 0:
            self.__calories = value
        else:
            raise ValueError('Expected float')
    
    def set_invima(self, value:str) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'invima'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, str):
            self.__invima = value
        else:
            raise ValueError('Expected str')