from dog import Dog
from pet_food import PetFood

class Daycare:
    """
    Esta clase representa a una guardería.

    Atributos:
        name (str): Nombre de la guardería.
    """

    # Constructor
    def __init__(self, name:str, pets:list = [], pets_food:list = []) -> None:
        """
        Inicializa la clase con los valores de todos los atributos de la clase.

        Se valida que cada valor enviado por parametro corresponda al tipo de dato del atributo
        """
        self.name = name
        self.pets = pets
        self.__pets_food = pets_food if pets_food != None else []

    # Metodos
    def add_pet(self, pet:Dog) -> None:
        if isinstance(pet, Dog):
            self.__pets.append(pet)
        else:
            raise ValueError('Expected Dog')

    def add_pet_food(self, pet_food:PetFood) -> None:
        if isinstance(pet_food, PetFood):
            self.__pets_food.append(pet_food)
        else:
            raise ValueError('Expected PetFood')

    # Getters y Setters
    @property
    def name(self) -> str:
        """ Devuelve el valor del atributo privado 'name' """
        return self.__name
    
    @name.setter
    def name(self, value:str) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'name'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, str):
            self.__name = value
        else:
            raise ValueError('Expected str')
        
    @property
    def pets(self) -> list:
        """ Devuelve el una lista del atributo privado 'pets' """
        return self.__pets
    
    @pets.setter
    def pets(self, value:list) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'pets'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, list):
            self.__pets = value
        else:
            raise ValueError('Expected list')
        
    @property
    def pets_food(self) -> list:
        """ Devuelve el valor del atributo privado 'pets_food' """
        return self.__pets_food
    
    @pets_food.setter
    def pets_food(self, value:list) -> None:
        """ 
        Establece un nuevo valor para el atributo privado 'pets_food'
    
        Valida que el valor enviado corresponda al tipo de dato del atributo
        """ 
        if isinstance(value, list):
            self.__pets_food = value
        else:
            raise ValueError('Expected list')
        
guarderia_1 = Daycare("DogTor")
        
concentrado_1 = PetFood("DogShow", 28000, 45.15, "dogshow123")
concentrado_2 = PetFood("DogGourmet", 35000, 50.4, "doggourmet123")

perro_1 = Dog("Zeus", "Rottweiler", 45.8, 3, concentrado_1)
perro_2 = Dog("Nala", "Golder R.", 8.5, 0, concentrado_1)
perro_3 = Dog("Atila", "Alabai", 58.9, 5, concentrado_2)

guarderia_2 = Daycare("CareDog", [perro_1, perro_3], [concentrado_1])

guarderia_1.add_pet(perro_2)
guarderia_1.add_pet_food(concentrado_2)

print(perro_1.get_data())
print(perro_2.get_data())
print(perro_3.get_data())

print(guarderia_1.pets)
print(guarderia_1.pets_food)
print(guarderia_2.pets)
print(guarderia_2.pets_food)

guarderia_1.add_pet(perro_1)
guarderia_1.add_pet_food(concentrado_1)

for pet in guarderia_1.pets:
    print(pet.get_data())

for pet_food in guarderia_1.pets_food:
    print(pet_food.get_data())
    print(pet_food.calculate_profitability())